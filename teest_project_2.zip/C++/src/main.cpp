#include "raylib.h"
#include "player.h"
#include <iostream>
int main(void)
{

    InitWindow(1280, 720, "game_project");
    SetTargetFPS(60);
    while (!WindowShouldClose())
    {
        BeginDrawing();

        ClearBackground(BLACK);
        DrawRectangle(0, 600, 100, 100, BLUE);
        player(Rectangle{0, 600, 1000, 10});

        DrawRectangle(0, 600, 1000, 10, BLUE);

        EndDrawing();
    }

    CloseWindow();
    return 0;
}